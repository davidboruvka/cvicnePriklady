/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOPR;


public class Nazevstranky {
    private String nazevstranky;
    private String barva;

    public Nazevstranky(String nazevstranky, String barva) {
        this.nazevstranky = nazevstranky;
        this.barva = barva;
    }
    
    

    public String getNazevstranky() {
        return nazevstranky;
    }

    public void setNazevstranky(String nazevstranky) {
        this.nazevstranky = nazevstranky;
    }

    public String getBarva() {
        return barva;
    }

    public void setBarva(String barva) {
        this.barva = barva;
    }
    
            
            
            
}

