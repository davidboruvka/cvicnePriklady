/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOPR;

import static OOPR.DAO.addNazevstranky;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class DAO {
    private static final String driverClassName = "org.apache.derby.jdbc.ClientDriver";
    private static final String connectionString = "jdbc:derby://localhost:1527/demoza1";
    private static final String dbLogin = "sa";
    private static final String dbPassword = "sa";
    private static java.sql.Connection connection = null;
    
    
    
    public static void open(){
        close();
        
        try {
            Class.forName(driverClassName);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Ovladač nebyl nenalezen.", ex);
        }
        
        try {
            connection = DriverManager.getConnection(connectionString, dbLogin, dbPassword);
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se otevřít připojení k databázi.", ex);
        }
        
    }
    
    public static void close(){
        if(connection == null)
            return;
        
        try {
            connection.close();
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se uzavřít spojení s databází.", ex);
        }
        
        connection = null;
    }
    
    public static void addNazevstranky(Nazevstranky ns) throws Exception{
        open();
        String sqlQuery = "insert into nazevstranky (nazevstranky, barva) values (?,?)";
        try
        {
            PreparedStatement ps = connection.prepareStatement(sqlQuery);
            ps.setString(1, ns.getNazevstranky());
            ps.setString(2, ns.getBarva());
            
            
            ps.execute();
            close();
        } catch(SQLException ex)
        {
            throw new RuntimeException("Nebylo možno vložit", ex);
        }
    }
    
    
    public static List<Nazevstranky> getAllNazevstranky(){
    open();
        List<Nazevstranky> nazevstranky = new LinkedList();
        String sqlQuery = "SELECT * FROM nazevstranky";
        
        try
        {
           PreparedStatement ps = connection.prepareStatement(sqlQuery);
           ResultSet rs = ps.executeQuery();
           while(rs.next())
           {
               nazevstranky.add(new Nazevstranky(rs.getString(1),rs.getString(2)));
           }
        }
        catch (SQLException ex)
        {
            throw new RuntimeException("err", ex);
        }
        return nazevstranky;
    }
}
