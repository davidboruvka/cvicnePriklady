/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

public class DAO {
    private static final String driverClassName = "org.apache.derby.jdbc.ClientDriver";
    private static final String connectionString = "jdbc:derby://localhost:1527/demo";
    private static final String dbLogin = "sa";
    private static final String dbPassword = "sa";
    private static java.sql.Connection connection = null;
    
    public static void open(){
        close();
        
        try {
            Class.forName(driverClassName);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Ovladač nebyl nenalezen.", ex);
        }
        
        try {
            connection = DriverManager.getConnection(connectionString, dbLogin, dbPassword);
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se otevřít připojení k databázi.", ex);
        }
        
    }
    
    public static void close(){
        if(connection == null)
            return;
        
        try {
            connection.close();
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se uzavřít spojení s databází.", ex);
        }
        
        connection = null;
    }
    
    private static void isDatabaseOpen(){
        if(connection == null)
        {
            open();
            throw new RuntimeException("Databáze není otevřena.");
        }
    }
    
    public static List<Person> getAllPpl()
    {
        isDatabaseOpen();
        List<Person> ppl = new LinkedList();
        String sqlQuery = "SELECT * FROM Zkouska2 order by vek DESC";
        
        try
        {
           PreparedStatement ps = connection.prepareStatement(sqlQuery);
           ResultSet rs = ps.executeQuery();
           while(rs.next())
           {
               ppl.add(new Person(rs.getString(2), rs.getInt(3)));
           }
        }
        catch (SQLException ex)
        {
            throw new RuntimeException("Nebylo možné vybrat lidi", ex);
        }
        return ppl;
    }
}
