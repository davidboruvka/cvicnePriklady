/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bussiness;

import data.DAO;
import java.util.List;

/**
 *
 * @author fojti
 */
public class Application {
    public static void addNumber(int n) throws Exception
    {
        DAO.open();
        try
        {
            DAO.addNumber(n);
        } catch(Exception ex)
        {
            DAO.close();
            throw new Exception(ex);
        }
    }
    public static List<Integer> getAllNums()
    {
        DAO.open();
        List<Integer> nums = DAO.getAllNums();
        DAO.close();
        return nums;
}
}
