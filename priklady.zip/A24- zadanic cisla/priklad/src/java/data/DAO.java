/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

public class DAO {
    private static final String driverClassName = "org.apache.derby.jdbc.ClientDriver";
    private static final String connectionString = "jdbc:derby://localhost:1527/demo";
    private static final String dbLogin = "sa";
    private static final String dbPassword = "sa";
    private static java.sql.Connection connection = null;
    
    public static void open(){
        close();
        
        try {
            Class.forName(driverClassName);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Ovladač nebyl nenalezen.", ex);
        }
        
        try {
            connection = DriverManager.getConnection(connectionString, dbLogin, dbPassword);
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se otevřít připojení k databázi.", ex);
        }
        
    }
    
    public static void close(){
        if(connection == null)
            return;
        
        try {
            connection.close();
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se uzavřít spojení s databází.", ex);
        }
        
        connection = null;
    }
    
    private static void isDatabaseOpen(){
        if(connection == null)
        {
            open();
            throw new RuntimeException("Databáze není otevřena.");
        }
    }
    
    public static void addNumber(int number) throws Exception
    {
        isDatabaseOpen();
        String sqlQuery = "INSERT INTO Zkouska (numval) VALUES (?)";
        try
        {
            PreparedStatement ps = connection.prepareStatement(sqlQuery, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, number);
            
            ps.execute();
        } catch(SQLException ex)
        {
            throw new RuntimeException("Nebylo možno vložit uživatele", ex);
        }   
    }
    
    public static List<Integer> getAllNums()
    {
        isDatabaseOpen();
        List<Integer> nums = new LinkedList();
        String sqlQuery = "SELECT * FROM Zkouska";
        
        try
        {
           PreparedStatement ps = connection.prepareStatement(sqlQuery);
           ResultSet rs = ps.executeQuery();
           while(rs.next())
           {
               nums.add(rs.getInt(2));
           }
        }
        catch (SQLException ex)
        {
            throw new RuntimeException("Nebylo možné vybrat čísla", ex);
        }
        return nums;
    }
}
