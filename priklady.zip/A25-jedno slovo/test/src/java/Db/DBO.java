/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Richard
 */
public class DBO {
    private String driverName       = "org.apache.derby.jdbc.ClientDriver";   
    private String connectionString;   
    private String dbUserName;   
    private String dbPassword;
    private Connection connection;
    
    public DBO(String driverName, String connectionString,String dbUserName, String dbPassword) {     
        this(connectionString, dbUserName, dbPassword); 
        this.driverName = driverName;   
     } 
 
    public DBO(String connectionString, String dbUserName, String dbPassword) {     
        this.connectionString = connectionString;     
        this.dbUserName = dbUserName;     
        this.dbPassword = dbPassword;   
    }
    
    public void open() {
        try {       
            Class.forName(this.driverName);     
        } catch (ClassNotFoundException ex) {       
            processError("Failed to register/load driver " + driverName, ex);     
        }  
        
        try {
            this.connection = java.sql.DriverManager.getConnection(connectionString, dbUserName, dbPassword); 
        } catch (SQLException ex) {
            processError("Failed to open connection using " + connectionString,ex); 
        }
    }
    
    public void close() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException ex) {
                processError("Cannot close conn to DB",ex);
            }
        }
    }
    
    public void insertWord(String word) {
        String sqlText = "INSERT INTO tbl(word) " + "VALUES (?)"; 
 
        try {       
            java.sql.PreparedStatement statement = connection.prepareStatement(sqlText);            
            statement.setString(1, word);

            statement.execute();
        } catch (SQLException ex) {       
            processError("Failed to process insert statement", ex);
        }
    }
    
    public List<String> getWords() {
        String sqlText = "SELECT word FROM tbl"; 
        ArrayList<String> result = new ArrayList<>();
        
        try {       
            java.sql.PreparedStatement statement = connection.prepareStatement(sqlText);            

            ResultSet set = statement.executeQuery();

            while (set.next()) {
                result.add(set.getString("word"));
            }

            set.close();
            return result;
        } catch (SQLException ex) {       
            processError("Failed to process insert statement",           ex);
        }
        return result;
    }
    
    public double avgLength() {
        String sqlText = "select avg(cast(length(word) as double)) AS a from tbl"; 
        double result = 0.0;
        
        try {      
            java.sql.PreparedStatement statement = connection.prepareStatement(sqlText);            

            ResultSet set = statement.executeQuery();

            set.next();
            result = set.getDouble("a");

            set.close();
            return result;
        } catch (SQLException ex) {       
            processError(           "Failed to process insert statement",           ex);
        } 
        return result;
    }
    
    protected void processError(       String errMessage, Throwable cause) {     
        DboException ex = new DboException(errMessage, cause);     
        processError(ex);   
    } 
 
    protected void processError(DboException dboEx) {     
        throw dboEx; 
    }
}
