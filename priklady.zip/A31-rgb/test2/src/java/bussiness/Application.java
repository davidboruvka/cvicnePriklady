package bussiness;

import data.AppBarva;
import data.DAO;
import java.util.List;


public class Application {
    public static List<AppBarva> getAllAppBarva()
    {
       DAO.open();
        List<AppBarva> appBarva = DAO.getAllAppBarva();
        DAO.close();
        return appBarva;
}
}
