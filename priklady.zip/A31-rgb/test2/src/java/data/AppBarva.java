/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author festi
 */
public class AppBarva {
    private int redColor;
    private int greenColor;
    private int blueColor;

    public AppBarva(int red, int green, int blue) {
        this.redColor = red;
        this.greenColor = green;
        this.blueColor = blue;
    }

    public int getRedColor() {
        return redColor;
    }

    public void setRedColor(int redColor) {
        this.redColor = redColor;
    }

    public int getGreenColor() {
        return greenColor;
    }

    public void setGreenColor(int greenColor) {
        this.greenColor = greenColor;
    }

    public int getBlueColor() {
        return blueColor;
    }

    public void setBlueColor(int blueColor) {
        this.blueColor = blueColor;
    }
    
    
    
    
    
}
