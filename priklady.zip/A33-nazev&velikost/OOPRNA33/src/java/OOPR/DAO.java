/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOPR;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Jeliman
 */
public class DAO {
    private static final String driverClassName = "org.apache.derby.jdbc.ClientDriver";
    private static final String connectionString = "jdbc:derby://localhost:1527/oopr3";
    private static final String dbLogin = "sa";
    private static final String dbPassword = "sa";
    private static java.sql.Connection connection = null;
    
    
    
    public static void open(){
        close();
        
        try {
            Class.forName(driverClassName);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Ovladač nebyl nenalezen.", ex);
        }
        
        try {
            connection = DriverManager.getConnection(connectionString, dbLogin, dbPassword);
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se otevřít připojení k databázi.", ex);
        }
        
    }
    
    public static void close(){
        if(connection == null)
            return;
        
        try {
            connection.close();
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se uzavřít spojení s databází.", ex);
        }
        
        connection = null;
    }
    
    public static void addFont(Font f) throws Exception{
        open();
        String sqlQuery = "insert into font (font, fontsize) values (?,?)";
        try
        {
            PreparedStatement ps = connection.prepareStatement(sqlQuery);
            ps.setString(1, f.getFontname());
            ps.setInt(2, f.getFontsize());
            
            
            ps.execute();
            close();
        } catch(SQLException ex)
        {
            throw new RuntimeException("Nebylo možno vložit font", ex);
        }
    }
    
    
    public static List<Font> getAllFonts(){
    open();
        List<Font> fonts = new LinkedList();
        String sqlQuery = "SELECT * FROM font";
        
        try
        {
           PreparedStatement ps = connection.prepareStatement(sqlQuery);
           ResultSet rs = ps.executeQuery();
           while(rs.next())
           {
               fonts.add(new Font(rs.getString(2),rs.getInt(3)));
           }
        }
        catch (SQLException ex)
        {
            throw new RuntimeException("Nebylo možné vybrat uživatele", ex);
        }
        return fonts;
    }
}
