/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOPR;

/**
 *
 * @author Jeliman
 */
public class Font {
    private String fontname;
    private int fontsize;

    public String getFontname() {
        return fontname;
    }

    public void setFontname(String fontname) {
        this.fontname = fontname;
    }

    public int getFontsize() {
        return fontsize;
    }

    public void setFontsize(int fontsize) {
        this.fontsize = fontsize;
    }

    public Font(String fontname, int fontsize) {
        this.fontname = fontname;
        this.fontsize = fontsize;
    }
    
    
}
