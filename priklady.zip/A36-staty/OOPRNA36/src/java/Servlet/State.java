/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

/**
 *
 * @author Jeliman
 */
public class State {
    private String st_name;
    private int obyvatel;
    private String pic_url;

    public String getSt_name() {
        return st_name;
    }

    public void setSt_name(String st_name) {
        this.st_name = st_name;
    }

    public int getObyvatel() {
        return obyvatel;
    }

    public void setObyvatel(int obyvatel) {
        this.obyvatel = obyvatel;
    }

    public String getPic_url() {
        return pic_url;
    }

    public void setPic_url(String pic_url) {
        this.pic_url = pic_url;
    }

    public State(String st_name, int obyvatel, String pic_url) {
        this.st_name = st_name;
        this.obyvatel = obyvatel;
        this.pic_url = pic_url;
    }
    
}
