/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Jeliman
 */
@WebServlet(name = "InsertData", urlPatterns = {"/InsertData"})
public class InsertData extends HttpServlet {
    private String name;
    private int obyvatel;
    private String pic_url;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
out.println("<!DOCTYPE html>\n" +
"<html>\n" +
"    <head>\n" +
"        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
"        <link rel=\"stylesheet\" type=\"text/css\" href=\"MyStyle.css\">\n" +
"        <title>Registration</title>\n" +
"    </head>\n" +
"    <body>\n" +
"                <form action=\"InsertData\" method=\"post\">\n" +
"                    <label for=\"Name\">State name</label>\n" +
"                    <input type=\"text\" name=\"name\" placeholder=\"State name\">\n" +
"                    <label for=\"surname\">Obyvatel</label>\n" +
"                    <input type=\"text\" name=\"obyvatel\" placeholder=\"Počet obyvatel\">\n" +
      "                 <label for=\"surname\">URL VLajky</label>\n" +
"                    <input type=\"text\" name=\"pic_url\" placeholder=\"Pic url\">\n" +
"                    <input type=\"submit\" value=\"Insert\">\n" +
"                </form>\n" +
"    </body>\n" +
"</html>\n" +
"");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        boolean reg_success = true;
        name = request.getParameter("name");
        obyvatel = Integer.parseInt(request.getParameter("obyvatel"));
        pic_url = request.getParameter("pic_url");
        
        
        String r_name = "[a-zA-ZěščřžýáíéďťňĚŠČŘŽÝÁÍÉĎŤŇ]{2,30}";
        String r_size = "[0-9]{1,2}";
        
        Pattern p_name = Pattern.compile(r_name);
        Matcher mn = p_name.matcher(name);
        boolean name_valid = mn.matches();
        
        Pattern p_age = Pattern.compile(r_size);
        Matcher ma = p_age.matcher(request.getParameter("obyvatel"));
        boolean age_valid = ma.matches();
        
        
        if(name.equals(""))
        {
          reg_success = false;
          out.println("<p class=\"red\">Nutno vyplnit pole název fontu.</p>");
        }
        if(!name_valid) 
        {
          reg_success = false;
          out.println("<p class=\"red\">jméno fotnu musí být 2 až 30 znaků dlouhé.</p>");
        }
        
        if(obyvatel<=0){
            reg_success=false;
            out.println("<p class=\"red\">Zadaná velikost musí být větší než 0 (NULA)</p>");
        }            
        
        if(reg_success){
            
            State s = new State(name, obyvatel, pic_url);
            try {
                DAO.addState(s);
                response.sendRedirect("InsertSuccess.jsp");
            } catch (Exception ex) {
                throw new RuntimeException("Nepodařilo se vložit uživatele", ex);
            }
            
           
        }else{
          
        processRequest(request, response);
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
