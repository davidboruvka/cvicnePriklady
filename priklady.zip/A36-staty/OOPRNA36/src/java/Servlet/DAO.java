/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Jeliman
 */
public class DAO {
    private static final String driverClassName = "org.apache.derby.jdbc.ClientDriver";
    private static final String connectionString = "jdbc:derby://localhost:1527/oopr3";
    private static final String dbLogin = "sa";
    private static final String dbPassword = "sa";
    private static java.sql.Connection connection = null;
    
    
    
    public static void open(){
        close();
        
        try {
            Class.forName(driverClassName);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Ovladač nebyl nenalezen.", ex);
        }
        
        try {
            connection = DriverManager.getConnection(connectionString, dbLogin, dbPassword);
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se otevřít připojení k databázi.", ex);
        }
        
    }
    
    public static void close(){
        if(connection == null)
            return;
        
        try {
            connection.close();
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se uzavřít spojení s databází.", ex);
        }
        
        connection = null;
    }
    
    public static void addState(State s) throws Exception{
        open();
        String sqlQuery = "insert into STATE (st_name, obyvatel, pic_url) values (?,?,?)";
        try
        {
            PreparedStatement ps = connection.prepareStatement(sqlQuery);
            ps.setString(1, s.getSt_name());
            ps.setInt(2, s.getObyvatel());
            ps.setString(3, s.getPic_url());
            
            
            ps.execute();
        } catch(SQLException ex)
        {
            throw new RuntimeException("Nebylo možno vložit font", ex);
        }finally{
            close();
        }
    }
    
    
    public static List<State> getAllStates(){
    open();
        List<State> states = new LinkedList();
        String sqlQuery = "SELECT * FROM state";
        
        try
        {
           PreparedStatement ps = connection.prepareStatement(sqlQuery);
           ResultSet rs = ps.executeQuery();
           while(rs.next())
           {
               states.add(new State(rs.getString(2),rs.getInt(3), rs.getString(4)));
           }
        }
        catch (SQLException ex)
        {
            throw new RuntimeException("Nebylo možné vybrat uživatele", ex);
        }finally{
            close();
        }
        return states;
    }
}
