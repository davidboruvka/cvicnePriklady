/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author MsLenka
 */
public class DAO {
    private static final String driverClassName = "org.apache.derby.jdbc.ClientDriver";
    private static final String connectionString = "jdbc:derby://localhost:1527/oopr3";
    private static final String dbLogin = "sa";
    private static final String dbPassword = "sa";
    private static java.sql.Connection connection = null;

    public static void open() {
        close();

        try {
            Class.forName(driverClassName);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Ovladač nebyl nenalezen.", ex);
        }

        try {
            connection = DriverManager.getConnection(connectionString, dbLogin, dbPassword);
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se otevřít připojení k databázi.", ex);
        }

    }

    public static void close() {
        if (connection == null) {
            return;
        }

        try {
            connection.close();
        } catch (SQLException ex) {
            throw new RuntimeException("Nepodařilo se uzavřít spojení s databází.", ex);
        }

        connection = null;
    }

    public static void addClanek(DataObject u) throws Exception {
        open();
        String sqlQuery = "INSERT INTO clanky (nazev,kratkytext) VALUES (?,?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sqlQuery);
            ps.setString(1, u.getNazev());
            ps.setString(2, u.getText());
            
            ps.execute();
            close();
        } catch (SQLException ex) {
            throw new RuntimeException("Nebylo možno vložit clanek", ex);
        }finally{
            close();
        }
    }
    
    public static List<DataObject> getAllClanek() {
        open();
        List<DataObject> dolist = new LinkedList();
        String sqlQuery = "SELECT * FROM  clanky order by priority asc";

        try {
            PreparedStatement ps = connection.prepareStatement(sqlQuery);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                dolist.add(new DataObject(rs.getString(2), rs.getString(3), rs.getInt(4)));
            }
        } catch (SQLException ex) {
            throw new RuntimeException("Nebylo možné vybrat clanky", ex);
        }finally{
            close();
        }
        return dolist;
    }
}
